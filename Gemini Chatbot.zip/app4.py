import streamlit as st
from google import genai
from google.genai import types

# --- 1. Configuration ---
# Use the newer Client class
api_key = st.secrets["GEMINI_API_KEY"]
client = genai.Client(api_key=api_key)
for model in client.models.list():
    print(model.name)

# 2. Define your System Instruction
sys_instruct = """
You are an expert in Data Science, AI, and Health Tech. 
Format: Use ## for headers. Always include a Python example for DS/AI topics.
Health Rule: Include a medical disclaimer for health queries.
"""


st.set_page_config(page_title="Gemini 2.5/3 Chat", page_icon="♊")
st.title("Google Gemini Assistant")

# --- 3. Session State ---
if "messages" not in st.session_state:
    st.session_state.messages = []

# --- 4. Display History ---
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# --- 5. Chat Logic ---
if prompt := st.chat_input("Ask Gemini anything..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        placeholder = st.empty()
        full_response = ""
        
        # Using Gemini 2.5 Flash (highly capable and free)
        # You can also try 'gemini-3-flash-preview' for the latest model
        response = client.models.generate_content_stream(
            model='gemini-2.5-flash',
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=sys_instruct,
                temperature=0.3 # Lower temperature for more factual DS/Health answers
            ) 
        )
        
        for chunk in response:
            full_response += chunk.text
            placeholder.markdown(full_response + "▌")
        
        placeholder.markdown(full_response)
        st.session_state.messages.append({"role": "assistant", "content": full_response})